from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import pypdf
import io

app = FastAPI()

# Allow your React frontend (running on localhost:5173) to talk to this backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for hackathon speed; restrict this later
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "Learn-With-Tech backend is running"}

@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    contents = await file.read()
    reader = pypdf.PdfReader(io.BytesIO(contents))

    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""

    # For now, just confirm we read it — next step is generating a course from this text
    return {
        "filename": file.filename,
        "pages": len(reader.pages),
        "preview": text[:300],
    }